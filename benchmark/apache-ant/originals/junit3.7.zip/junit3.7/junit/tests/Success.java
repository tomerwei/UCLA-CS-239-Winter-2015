package junit.tests;

import java.util.Vector;
import junit.framework.*;

/**
 * A test case testing the testing framework.
 *
 */
public class Success extends TestCase {
	
	public Success(String name) {
		super(name);
	}
	public void test() {
	}
}